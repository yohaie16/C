#include "assembler/assembler.h"

int main(int argc, char ** argv){
    return assembler(argc-1,argv+1);
}
