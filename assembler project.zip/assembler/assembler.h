#ifndef __ASSEMBLER_H_
#define __ASSEMBLER_H_



int assembler(int file_count, char ** file_names);

#endif
