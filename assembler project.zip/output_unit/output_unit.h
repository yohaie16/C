#ifndef _OUTPUT_UNIT_H_
#define _OUTPUT_UNIT_H_
#include "../trie/trie.h"
#include "../vector/vector.h"
#include "../share/share.h" 

void mmn14_output(char * base_name, const struct object_file *obj, const char *out_dir);

#endif 