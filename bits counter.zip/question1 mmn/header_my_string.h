#define CS_IS_BIGGER    1
#define CS_EQUAL_TO_CT  0
#define CT_IS_BIGGER    -1
#define CHAR_IS_NOT_FOUND  -1
#define MAX_LENGTH  80
